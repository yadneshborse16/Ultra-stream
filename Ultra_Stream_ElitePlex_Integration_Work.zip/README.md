# Ultra Stream — Android Studio project

Premium dark Android media app with a hollow pentagon mark, reddish-gold accents, catalog search, a Media3 player, PiP toggle, cache clearing, and authorized M3U/M3U8 playlist support.

## ElitePlex catalog connector

This version adds a read-only connector for the API routes found in the supplied ElitePlex APK:
- `/mb/home?page=1`
- `/mb/movies?page=1`
- `/mb/series?page=1`
- `/mb/rank?page=1`
- `/mb/search?q=...`
- `/mb/detail/{subjectId}` and `/mb/stream/{subjectId}` for playback resolution attempts

The app attempts to load ElitePlex home data on launch and includes Movies, Series, Popular, and search actions. JSON parsing is intentionally tolerant because the live API schema has not been verified from this environment. If the API is offline, has changed, requires additional headers, or returns a different schema, the app will show an error instead of inventing titles.

**Important status:** This is an integration work-in-progress, not a tested APK. The runtime environment has no Android SDK/Gradle installation and cannot reach the API host to validate responses, so catalog loading and stream resolution must still be verified with a network-enabled Android Studio build. The code does not bypass DRM, authentication, subscriptions, or paywalls. Playback only works if the API returns an accessible stream URL and you are authorized to use it.

## Build APK

Open this folder in Android Studio and let Gradle sync. Or push the folder to a GitHub repository and run the included **Build Android APK** workflow. The workflow uploads `app-debug.apk` as an artifact.
