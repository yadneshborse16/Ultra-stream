package com.ultrastream.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class MediaTitle(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val posterUrl: String? = null,
    val sourceName: String,
    val channelName: String? = null,
    val streamUrl: String? = null
)

/** Loads a user-supplied, authorized M3U/M3U8 playlist. It does not scrape sites or bypass DRM. */
object PlaylistLoader {
    suspend fun load(playlistUrl: String): List<MediaTitle> = withContext(Dispatchers.IO) {
        val parsed = URL(playlistUrl.trim())
        require(parsed.protocol == "https" || parsed.protocol == "http") { "Enter a valid HTTP(S) playlist URL." }
        val connection = (parsed.openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 18000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "UltraStream/1.0 Android")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("Playlist server returned HTTP $code.")
            val text = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            parse(text, parsed.host ?: "M3U playlist")
        } finally {
            connection.disconnect()
        }
    }

    fun parse(text: String, sourceLabel: String = "M3U playlist"): List<MediaTitle> {
        val output = mutableListOf<MediaTitle>()
        var pendingTitle: String? = null
        var pendingLogo: String? = null
        var pendingGroup: String? = null
        var pendingDescription: String? = null
        text.lineSequence().map { it.trim().removePrefix("\uFEFF") }.forEach { line ->
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val comma = line.lastIndexOf(',')
                    pendingTitle = if (comma >= 0 && comma < line.lastIndex) line.substring(comma + 1).trim() else "Untitled stream"
                    pendingLogo = Regex("tvg-logo=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)?.takeIf(String::isNotBlank)
                    pendingGroup = Regex("group-title=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)?.takeIf(String::isNotBlank)
                    pendingDescription = Regex("tvg-name=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)?.takeIf(String::isNotBlank)
                }
                line.isNotBlank() && !line.startsWith("#") && (line.startsWith("http://", true) || line.startsWith("https://", true)) -> {
                    val title = pendingTitle ?: line.substringAfterLast('/').substringBefore('?').ifBlank { "Stream" }
                    val category = pendingGroup?.takeIf { it.isNotBlank() } ?: "Live TV"
                    output += MediaTitle(
                        id = line.hashCode().toString(), name = title, category = category,
                        description = pendingDescription ?: "From your configured playlist.",
                        posterUrl = pendingLogo, sourceName = sourceLabel,
                        channelName = title,
                        streamUrl = line
                    )
                    pendingTitle = null; pendingLogo = null; pendingGroup = null; pendingDescription = null
                }
            }
        }
        output.distinctBy { it.streamUrl }
    }
}
