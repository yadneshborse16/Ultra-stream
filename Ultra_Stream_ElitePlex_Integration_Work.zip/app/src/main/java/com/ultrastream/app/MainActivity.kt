package com.ultrastream.app

import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF050505)
private val Panel = Color(0xFF14110D)
private val Gold = Color(0xFFFFC56A)
private val RedGold = Color(0xFFFF6548)
private val Muted = Color(0xFFAAA29A)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var isPlaying by mutableStateOf(false)
    private var pipEnabled by mutableStateOf(true)
    private var selectedTitle by mutableStateOf<MediaTitle?>(null)
    private var settingsOpen by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ultra_stream_settings", MODE_PRIVATE)
        pipEnabled = prefs.getBoolean("pip_enabled", true)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = RedGold, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
                when {
                    settingsOpen -> SettingsScreen(
                        pipEnabled = pipEnabled,
                        savedPlaylistUrl = prefs.getString("playlist_url", "") ?: "",
                        onPipChange = { pipEnabled = it; prefs.edit().putBoolean("pip_enabled", it).apply() },
                        onSavePlaylist = { prefs.edit().putString("playlist_url", it.trim()).apply() },
                        onClearCache = {
                            val cleared = runCatching {
                                cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                                externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
                                true
                            }.getOrDefault(false)
                            cleared
                        },
                        onBack = { settingsOpen = false }
                    )
                    selectedTitle != null -> PlayerScreen(
                        title = selectedTitle!!, existingPlayer = player,
                        onPlayer = { player = it }, onPlaying = { isPlaying = it },
                        onBack = { selectedTitle = null; isPlaying = false; player?.release(); player = null }
                    )
                    else -> HomeScreen(
                        savedPlaylistUrl = prefs.getString("playlist_url", "") ?: "",
                        savedManualStreams = decodeManualStreams(prefs.getString("manual_streams", "[]") ?: "[]"),
                        onOpenSettings = { settingsOpen = true },
                        onSavePlaylist = { prefs.edit().putString("playlist_url", it.trim()).apply() },
                        onSaveManualStreams = { prefs.edit().putString("manual_streams", encodeManualStreams(it)).apply() },
                        onTitle = { title ->
                            if (title.sourceName == "ElitePlex") {
                                lifecycleScope.launch {
                                    val resolved = runCatching { ElitePlexConnector.resolvePlayableUrl(title.id) }.getOrNull()
                                    selectedTitle = if (!resolved.isNullOrBlank()) title.copy(
                                        streamUrl = resolved,
                                        description = title.description + "\n\nStream resolved from ElitePlex."
                                    ) else title
                                }
                            } else selectedTitle = title
                        }
                    )
                }
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isPlaying && player != null && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }

    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}

@Composable
private fun PentagonLogo(modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 42.dp) {
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height; val cx = w / 2f; val cy = h / 2f; val r = minOf(w, h) * .40f
        val path = Path()
        for (i in 0..4) {
            val a = Math.toRadians(-90.0 + i * 72.0)
            val p = Offset(cx + r * kotlin.math.cos(a).toFloat(), cy + r * kotlin.math.sin(a).toFloat())
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        path.close()
        drawPath(path, RedGold.copy(alpha = .18f), style = Stroke(width = w * .22f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(path, Gold.copy(alpha = .30f), style = Stroke(width = w * .13f, cap = StrokeCap.Round))
        drawPath(path, Brush.linearGradient(listOf(RedGold, Gold, RedGold)), style = Stroke(width = w * .055f, cap = StrokeCap.Round))
    }
}

@Composable
private fun HomeScreen(savedPlaylistUrl: String, savedManualStreams: List<MediaTitle>, onOpenSettings: () -> Unit, onSavePlaylist: (String) -> Unit, onSaveManualStreams: (List<MediaTitle>) -> Unit, onTitle: (MediaTitle) -> Unit) {
    val scope = rememberCoroutineScope()
    var category by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    var playlistUrl by remember { mutableStateOf(savedPlaylistUrl) }
    var items by remember { mutableStateOf<List<MediaTitle>>(savedManualStreams) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect ElitePlex catalog or add an authorized playlist/direct stream.") }
    var addPlaylistDialog by remember { mutableStateOf(false) }
    var directDialog by remember { mutableStateOf(false) }
    var directName by remember { mutableStateOf("") }
    var directUrl by remember { mutableStateOf("") }

    fun loadElitePlex(kind: String = "home", searchText: String = "") {
        loading = true
        status = if (kind == "search") "Searching ElitePlex…" else "Loading ElitePlex catalog…"
        scope.launch {
            val result = runCatching {
                when (kind) {
                    "movies" -> ElitePlexConnector.movies()
                    "series" -> ElitePlexConnector.series()
                    "popular" -> ElitePlexConnector.ranked()
                    "search" -> ElitePlexConnector.search(searchText)
                    else -> ElitePlexConnector.home()
                }
            }
            loading = false
            result.onSuccess { loaded ->
                if (loaded.isNotEmpty()) {
                    val retained = items.filter { it.sourceName != "ElitePlex" }
                    items = (retained + loaded).distinctBy { it.id }
                    status = "Loaded ${loaded.size} catalog entries from ElitePlex. Playback links are resolved separately."
                } else status = "ElitePlex responded, but no catalog entries were recognized. API format may have changed."
            }.onFailure { status = "ElitePlex unavailable: ${it.message ?: "network/API error"}" }
        }
    }

    fun loadPlaylist(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) { status = "Enter an M3U/M3U8 playlist URL first."; return }
        loading = true; status = "Loading playlist…"
        onSavePlaylist(clean)
        scope.launch {
            val result = runCatching { PlaylistLoader.load(clean) }
            loading = false
            result.onSuccess { loaded ->
                items = (loaded + items.filter { it.sourceName == "Manual source" }).distinctBy { it.streamUrl }
                status = if (loaded.isEmpty()) "The playlist loaded, but no HTTP(S) stream entries were found." else "Loaded ${loaded.size} entries from your playlist."
            }.onFailure { status = it.message ?: "Could not load playlist. Check the URL and connection." }
        }
    }

    LaunchedEffect(savedPlaylistUrl) {
        if (savedPlaylistUrl.isNotBlank() && items.isEmpty()) loadPlaylist(savedPlaylistUrl)
    }

    LaunchedEffect(Unit) { loadElitePlex("home") }

    LaunchedEffect(query) {
        if (query.trim().length >= 2) {
            delay(650)
            loadElitePlex("search", query.trim())
        }
    }

    val categories = listOf("All", "Live TV", "Movies", "Series", "Anime", "Cartoons")
    val visible = remember(items, category, query) {
        items.filter { item ->
            (category == "All" || item.category.contains(category, true) || (category == "Live TV" && (item.channelName != null || item.category.contains("tv", true)))) &&
                (query.isBlank() || item.name.contains(query, true) || item.description.contains(query, true) || item.category.contains(query, true) || item.sourceName.contains(query, true))
        }
    }

    if (addPlaylistDialog) AlertDialog(
        onDismissRequest = { addPlaylistDialog = false }, containerColor = Panel,
        title = { Text("Add playlist", color = Color.White) },
        text = { Column { Text("Use an M3U/M3U8 URL you are authorized to access.", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(10.dp)); OutlinedTextField(value = playlistUrl, onValueChange = { playlistUrl = it }, label = { Text("Playlist URL") }, singleLine = true) } },
        confirmButton = { TextButton(onClick = { addPlaylistDialog = false; loadPlaylist(playlistUrl) }) { Text("LOAD", color = Gold) } },
        dismissButton = { TextButton(onClick = { addPlaylistDialog = false }) { Text("CANCEL") } }
    )
    if (directDialog) AlertDialog(
        onDismissRequest = { directDialog = false }, containerColor = Panel,
        title = { Text("Add direct stream", color = Color.White) },
        text = { Column {
            Text("Enter a direct, authorized media URL (for example HLS .m3u8 or MP4). A webpage URL is not a video stream.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = directName, onValueChange = { directName = it }, label = { Text("Stream name") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = directUrl, onValueChange = { directUrl = it }, label = { Text("Direct media URL") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
        } },
        confirmButton = { TextButton(onClick = {
            val uri = directUrl.trim()
            if ((uri.startsWith("https://") || uri.startsWith("http://")) && directName.isNotBlank()) {
                val title = MediaTitle(uri.hashCode().toString(), directName.trim(), "Live TV", "User-added direct stream.", sourceName = "Manual source", channelName = directName.trim(), streamUrl = uri)
                items = (items.filterNot { it.streamUrl == uri } + title)
                onSaveManualStreams(items.filter { it.sourceName == "Manual source" })
                directDialog = false; directName = ""; directUrl = ""; status = "Direct stream added. Tap its card to play."
            } else status = "Enter a name and a valid HTTP(S) direct media URL."
        }) { Text("ADD", color = Gold) } },
        dismissButton = { TextButton(onClick = { directDialog = false }) { Text("CANCEL") } }
    )

    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Column(Modifier.padding(horizontal = 18.dp).padding(top = 22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PentagonLogo(); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text("ULTRA STREAM", fontWeight = FontWeight.Black, letterSpacing = 2.2.sp, fontSize = 18.sp); Text("YOUR MEDIA. ONE DESTINATION.", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp) }
                    IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Gold) }
                }
                Spacer(Modifier.height(22.dp))
                Box(Modifier.fillMaxWidth().height(170.dp).background(Brush.linearGradient(listOf(Color(0xFF35190F), Color(0xFF17110B), Color.Black)), RoundedCornerShape(22.dp)).padding(20.dp)) {
                    Column(Modifier.align(Alignment.CenterStart)) {
                        Text("ULTRA STREAM", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp)); Text("Everything you\nchoose to watch.", fontSize = 27.sp, lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(8.dp)); Text("Connect a playlist or add a direct stream", color = Muted, fontSize = 11.sp)
                    }
                    PentagonLogo(Modifier.align(Alignment.TopEnd), 48.dp)
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search your connected library", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) }, shape = RoundedCornerShape(15.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFF403024), focusedBorderColor = Gold, unfocusedContainerColor = Panel, focusedContainerColor = Panel))
                Spacer(Modifier.height(12.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    categories.forEach { FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF8F3B23), selectedLabelColor = Gold)) }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { loadElitePlex("home") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8F3B23)), modifier = Modifier.weight(1f)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(5.dp)); Text("ElitePlex") }
                    OutlinedButton(onClick = { addPlaylistDialog = true }, border = androidx.compose.foundation.BorderStroke(1.dp, Gold), modifier = Modifier.weight(1f)) { Icon(Icons.Default.LiveTv, null, tint = Gold); Spacer(Modifier.width(5.dp)); Text("Playlist", color = Gold) }
                    OutlinedButton(onClick = { directDialog = true }, border = androidx.compose.foundation.BorderStroke(1.dp, Gold)) { Icon(Icons.Default.Add, null, tint = Gold) }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { loadElitePlex("movies") }) { Text("MOVIES", color = Gold) }
                    TextButton(onClick = { loadElitePlex("series") }) { Text("SERIES", color = Gold) }
                    TextButton(onClick = { loadElitePlex("popular") }) { Text("POPULAR", color = Gold) }
                }
                Spacer(Modifier.height(12.dp))
                Text(status, color = if (status.startsWith("Could not") || status.startsWith("Enter")) RedGold else Muted, fontSize = 12.sp)
                if (loading) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold) }
                Spacer(Modifier.height(18.dp))
                Text(if (query.isBlank()) "YOUR LIBRARY" else "SEARCH RESULTS", fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
        if (visible.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 26.dp).background(Panel, RoundedCornerShape(20.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LiveTv, contentDescription = null, tint = Gold, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(12.dp)); Text(if (items.isEmpty()) "Connecting to ElitePlex library" else "No matching titles", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(6.dp)); Text(if (items.isEmpty()) "The app requests real ElitePlex catalog data. If its API is unreachable, connect an authorized playlist or direct stream instead." else "Try another search or category.", color = Muted, fontSize = 12.sp)
                    if (items.isEmpty()) { Spacer(Modifier.height(14.dp)); Button(onClick = { loadElitePlex("home") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8F3B23))) { Text("RETRY ELITEPLEX") }; TextButton(onClick = { addPlaylistDialog = true }) { Text("CONNECT PLAYLIST", color = Gold) } }
                }
            }
        } else items(visible, key = { it.id + it.streamUrl.orEmpty() }) { title -> ResultCard(title) { onTitle(title) } }
    }
}

@Composable
private fun ResultCard(title: MediaTitle, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp).background(Panel, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(86.dp).height(106.dp).background(Color(0xFF20160F), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
            if (!title.posterUrl.isNullOrBlank()) AsyncImage(model = title.posterUrl, contentDescription = "${title.name} poster", modifier = Modifier.fillMaxSize()) else PentagonLogo(size = 34.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp)); Text("${title.category.uppercase()}  •  ${title.sourceName}", color = Gold, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp)); Text(title.description, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.PlayArrow, contentDescription = "Play ${title.name}", tint = Gold, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun SettingsScreen(pipEnabled: Boolean, savedPlaylistUrl: String, onPipChange: (Boolean) -> Unit, onSavePlaylist: (String) -> Unit, onClearCache: () -> Boolean, onBack: () -> Unit) {
    var playlistUrl by remember(savedPlaylistUrl) { mutableStateOf(savedPlaylistUrl) }
    var message by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White) }; Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(20.dp))
        Text("PLAYBACK", color = Gold, fontSize = 10.sp, letterSpacing = 1.6.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Popup player", fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(4.dp)); Text("Picture-in-Picture when leaving the app", color = Muted, fontSize = 12.sp) }
            Switch(checked = pipEnabled, onCheckedChange = onPipChange, colors = SwitchDefaults.colors(checkedThumbColor = Gold, checkedTrackColor = Color(0xFF8F3B23)))
        }
        Spacer(Modifier.height(20.dp)); Text("CONTENT SOURCE", color = Gold, fontSize = 10.sp, letterSpacing = 1.6.sp); Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp)) {
            Text("M3U / M3U8 playlist", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp)); Text("Use a playlist URL you are authorized to access. The app does not bypass logins, DRM, or paywalls.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp)); OutlinedTextField(value = playlistUrl, onValueChange = { playlistUrl = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Playlist URL") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            Spacer(Modifier.height(8.dp)); Button(onClick = { onSavePlaylist(playlistUrl); message = "Playlist URL saved. Return home to load it." }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8F3B23))) { Text("SAVE PLAYLIST") }
        }
        Spacer(Modifier.height(20.dp)); Text("STORAGE", color = Gold, fontSize = 10.sp, letterSpacing = 1.6.sp); Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { confirmClear = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = Gold, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("Clear cache", fontWeight = FontWeight.SemiBold); Text("Remove temporary cached files", color = Muted, fontSize = 12.sp) }
        }
        if (message.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(message, color = Gold, fontSize = 12.sp) }
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, containerColor = Panel, title = { Text("Clear cache?") }, text = { Text("Temporary files will be removed. Your saved playlist URL and settings will remain.", color = Muted) }, confirmButton = { TextButton(onClick = { val ok = onClearCache(); confirmClear = false; message = if (ok) "Cache cleared." else "Some temporary files could not be removed." }) { Text("CLEAR CACHE", color = Gold) } }, dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("CANCEL") } })
}

@Composable
private fun PlayerScreen(title: MediaTitle, existingPlayer: ExoPlayer?, onPlayer: (ExoPlayer) -> Unit, onPlaying: (Boolean) -> Unit, onBack: () -> Unit) {
    BackHandler { onBack() }
    val context = LocalContext.current
    var localPlayer by remember(title.id) { mutableStateOf(existingPlayer) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(title.id) {
        if (localPlayer == null) {
            val exo = ExoPlayer.Builder(context).build()
            val url = title.streamUrl
            if (!url.isNullOrBlank()) {
                exo.setMediaItem(MediaItem.fromUri(url)); exo.prepare(); exo.playWhenReady = true
                exo.addListener(object : Player.Listener {
                    override fun onPlayerError(e: androidx.media3.common.PlaybackException) { error = e.message ?: "Playback failed. Check whether the stream URL is valid and accessible." }
                })
            } else error = "This item has no direct playable URL. Add a direct media URL or use a playable playlist entry."
            localPlayer = exo; onPlayer(exo)
        }
    }
    DisposableEffect(localPlayer) {
        val p = localPlayer
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) = onPlaying(playing)
            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_READY) error = null }
            override fun onPlayerError(e: androidx.media3.common.PlaybackException) { error = e.message ?: "Playback failed. The source may be unavailable or unsupported." }
        }
        p?.addListener(listener)
        onDispose { p?.removeListener(listener) }
    }
    LaunchedEffect(localPlayer) { while (true) { localPlayer?.let { position = it.currentPosition.coerceAtLeast(0L); duration = it.duration.takeIf { d -> d > 0L } ?: 0L; onPlaying(it.isPlaying) }; delay(500) } }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White) }
            Column(Modifier.weight(1f)) { Text(title.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("ULTRA STREAM PLAYER", color = Gold, fontSize = 10.sp, letterSpacing = 1.2.sp) }
        }
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black), contentAlignment = Alignment.Center) {
            if (localPlayer != null && !title.streamUrl.isNullOrBlank()) AndroidView(factory = { ctx -> PlayerView(ctx).apply { player = localPlayer; useController = true; setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS); keepScreenOn = true } }, modifier = Modifier.fillMaxSize(), update = { it.player = localPlayer })
            else Column(horizontalAlignment = Alignment.CenterHorizontally) { PentagonLogo(size = 48.dp); Spacer(Modifier.height(10.dp)); Text("No playable stream", color = Muted, fontSize = 12.sp) }
        }
        Column(Modifier.padding(20.dp)) {
            Text(title.name, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text("${title.category} • ${title.sourceName}", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp)); Text(title.description, color = Muted, fontSize = 13.sp)
            if (duration > 0) { Spacer(Modifier.height(12.dp)); Text("${formatTime(position)} / ${formatTime(duration)}", color = Muted, fontSize = 12.sp); Slider(value = position.toFloat().coerceIn(0f, duration.toFloat()), onValueChange = { position = it.toLong() }, onValueChangeFinished = { localPlayer?.seekTo(position) }, valueRange = 0f..duration.toFloat(), colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = RedGold)) }
            if (error != null) { Spacer(Modifier.height(12.dp)); Text(error!!, color = RedGold, fontSize = 12.sp); TextButton(onClick = { error = null; localPlayer?.prepare(); localPlayer?.play() }) { Text("RETRY", color = Gold) } }
        }
    }
}

private fun formatTime(ms: Long): String { val sec = (ms / 1000).coerceAtLeast(0); return "%d:%02d".format(sec / 60, sec % 60) }

private fun encodeManualStreams(items: List<MediaTitle>): String {
    val array = JSONArray()
    items.filter { it.sourceName == "Manual source" && !it.streamUrl.isNullOrBlank() }.forEach { item ->
        array.put(JSONObject().put("id", item.id).put("name", item.name).put("category", item.category)
            .put("description", item.description).put("sourceName", item.sourceName)
            .put("channelName", item.channelName ?: "").put("streamUrl", item.streamUrl ?: ""))
    }
    return array.toString()
}

private fun decodeManualStreams(json: String): List<MediaTitle> = runCatching {
    val array = JSONArray(json)
    (0 until array.length()).mapNotNull { i ->
        val obj = array.getJSONObject(i)
        val url = obj.optString("streamUrl").takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: return@mapNotNull null
        MediaTitle(obj.optString("id", url.hashCode().toString()), obj.optString("name", "Stream"),
            obj.optString("category", "Live TV"), obj.optString("description", "User-added direct stream."),
            sourceName = "Manual source", channelName = obj.optString("channelName").ifBlank { null }, streamUrl = url)
    }
}.getOrDefault(emptyList())
