package com.ultrastream.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Read-only catalog connector for the ElitePlex API routes observed in the supplied APK.
 * The API's live availability and response schema still need device/network verification.
 */
object ElitePlexConnector {
    private const val BASE = "https://eliteplex-api.vercel.app/mb/"

    suspend fun home(page: Int = 1) = fetch("home?page=$page", "ElitePlex")
    suspend fun movies(page: Int = 1) = fetch("movies?page=$page", "Movies")
    suspend fun series(page: Int = 1) = fetch("series?page=$page", "Series")
    suspend fun search(query: String) = fetch("search?q=${URLEncoder.encode(query, "UTF-8")}", "Search")
    suspend fun ranked(page: Int = 1) = fetch("rank?page=$page", "Popular")
    suspend fun suggest(query: String) = fetch("suggest?q=${URLEncoder.encode(query, "UTF-8")}", "Suggestions")

    suspend fun resolvePlayableUrl(subjectId: String): String? = withContext(Dispatchers.IO) {
        val safeId = URLEncoder.encode(subjectId.removePrefix("eliteplex:"), "UTF-8")
        // These detail/stream routes are present in the supplied ElitePlex APK.
        val detail = requestJson("detail/$safeId")
        val stream = requestJson("stream/$safeId")
        findPlayableUrl(stream) ?: findPlayableUrl(detail)
    }

    private fun requestJson(path: String): JSONObject? {
        val conn = (URL(BASE + path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 15000; requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "UltraStream/1.0 Android")
        }
        return try {
            if (conn.responseCode !in 200..299) null
            else JSONObject(conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } catch (_: Exception) { null } finally { conn.disconnect() }
    }

    private fun findPlayableUrl(value: Any?): String? {
        val keys = setOf("url", "playurl", "streamurl", "directplayurl", "videourl", "m3u8", "mp4", "play_url", "stream_url")
        when (value) {
            is JSONObject -> {
                val it = value.keys()
                while (it.hasNext()) {
                    val key = it.next(); val child = value.opt(key)
                    if (key.lowercase() in keys && child is String && child.startsWith("http", true)) return child
                }
                val nested = value.keys()
                while (nested.hasNext()) findPlayableUrl(value.opt(nested.next()))?.let { return it }
            }
            is JSONArray -> for (i in 0 until value.length()) findPlayableUrl(value.opt(i))?.let { return it }
            is String -> if (value.startsWith("http", true) && (".m3u8" in value.lowercase() || ".mp4" in value.lowercase() || ".mpd" in value.lowercase())) return value
        }
        return null
    }

    private suspend fun fetch(path: String, label: String): List<MediaTitle> = withContext(Dispatchers.IO) {
        val url = URL(BASE + path)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000; readTimeout = 15000; requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "UltraStream/1.0 Android")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("ElitePlex API returned HTTP $code for $label")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = runCatching { JSONObject(body) }.getOrNull()
            val array = root?.let(::findContentArray) ?: runCatching { JSONArray(body) }.getOrNull()
                ?: throw IllegalStateException("ElitePlex returned an unrecognized response for $label")
            val objects = mutableListOf<JSONObject>()
            collectObjects(array, objects)
            objects.mapNotNull { obj ->
                val title = firstString(obj, "title", "name", "subjectName", "displayName", "originalTitle") ?: return@mapNotNull null
                val id = firstString(obj, "subjectId", "id", "subject_id", "videoId", "contentId") ?: "$label-${title.hashCode()}"
                val poster = firstString(obj, "posterUrl", "posterPath", "cover", "coverUrl", "image", "thumbnail", "backdropPath")
                    ?.let { if (it.startsWith("http", true)) it else "https://image.tmdb.org/t/p/w500" + if (it.startsWith("/")) it else "/$it" }
                val description = firstString(obj, "description", "overview", "intro", "summary", "plot") ?: "Catalog details supplied by ElitePlex."
                val mediaType = firstString(obj, "type", "mediaType", "category") ?: label
                MediaTitle(id = "eliteplex:$id", name = title, category = normalizeCategory(mediaType, label),
                    description = description, posterUrl = poster, sourceName = "ElitePlex", streamUrl = null)
            }.distinctBy { it.id }
        } finally { conn.disconnect() }
    }

    private fun collectObjects(array: JSONArray, output: MutableList<JSONObject>) {
        for (i in 0 until array.length()) {
            when (val value = array.opt(i)) {
                is JSONObject -> {
                    if (firstString(value, "title", "name", "subjectName", "displayName", "originalTitle") != null) output += value
                    val keys = value.keys()
                    while (keys.hasNext()) {
                        val child = value.opt(keys.next())
                        if (child is JSONArray) collectObjects(child, output)
                        else if (child is JSONObject) {
                            val nested = findContentArray(child)
                            if (nested != null) collectObjects(nested, output)
                        }
                    }
                }
            }
        }
    }

    private fun findContentArray(root: JSONObject): JSONArray? {
        val preferred = listOf("data", "results", "items", "subjects", "list", "records", "content", "movieList", "seriesList", "sections")
        for (key in preferred) {
            val value = root.opt(key)
            if (value is JSONArray && (value.length() == 0 || value.optJSONObject(0) != null)) return value
            if (value is JSONObject) findContentArray(value)?.let { return it }
        }
        val keys = root.keys()
        while (keys.hasNext()) {
            val value = root.opt(keys.next())
            if (value is JSONObject) findContentArray(value)?.let { return it }
        }
        return null
    }

    private fun firstString(obj: JSONObject, vararg keys: String): String? {
        for (key in keys) {
            val value = obj.opt(key)
            if (value is String && value.isNotBlank() && value != "null") return value
            if (value is Number) return value.toString()
        }
        return null
    }

    private fun normalizeCategory(raw: String, fallback: String): String {
        val value = raw.lowercase()
        return when {
            "series" in value || "tv" in value || "show" in value -> "Series"
            "movie" in value || "film" in value -> "Movies"
            "anime" in value -> "Anime"
            "cartoon" in value || "animation" in value -> "Cartoons"
            else -> if (fallback == "ElitePlex" || fallback == "Popular" || fallback == "Search" || fallback == "Suggestions") "Movies & Series" else fallback
        }
    }
}
